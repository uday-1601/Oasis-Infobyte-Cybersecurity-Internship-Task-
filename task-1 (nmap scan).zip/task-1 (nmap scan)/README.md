# Basic Network Scanning with Nmap

## Objective
Perform a network scan to identify open ports and services using Nmap.

## Target
 IP Address: `192.168.1.10`
 Host Status: Up (reachable)

## Tools Used
 Nmap v7.97
 Windows Command Prompt

## Scan Command Used
```bash
nmap -sV -O 192.168.1.10 -oN nmap_scan_results.txt

